unzip project.zip
rm project.zip
