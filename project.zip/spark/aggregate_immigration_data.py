from pyspark.sql import SparkSession
import os
from lib.file_finder import FileFinder
from lib.rdd_creator import RDDCreator
import logging
import pyspark.sql.functions as f 
from functools import reduce 
from pyspark.sql import DataFrame

def unionAll(*dfs):
    return reduce(DataFrame.union, dfs)


CORE_PATH = '/mnt1/data'

def generate_immigration_rdd(spark, dataset):
  return (spark.read.format("com.github.saurfang.sas.spark").load(dataset))

def return_rdd_column_subset(dataset):
  
  dataset = dataset.select(
    dataset.i94yr.alias('arrival_year'),
    dataset.i94mon.alias('arrival_month'),
    dataset.arrdate.alias('arrival_date'),
    dataset.depdate.alias('departure_date'),
    dataset.i94addr.alias('state'),
    dataset.i94port.alias('city_of_arrival'),
    dataset.gender,
    dataset.biryear.alias('age')      
  )

  dataset = dataset.filter(dataset.state.isNotNull())

  return dataset

def create_sex_distribution_frame(logger, all_data, female_data):
 
  distribution_frame = all_data.join(
    female_data,
    [all_data.state == female_data.f_state, all_data.arrival_month == female_data.f_arrival_month]
  ).select('state', 'arrival_month', 'count', 'f_count')

  logger.error('DISTRIBUTION FRAME =>')
  logger.error(distribution_frame.show(50))
  distribution_frame = distribution_frame.withColumn('female_distribution', distribution_frame['f_count'] / distribution_frame['count'])

  return distribution_frame

def create_female_distribution(logger, dataset):

    logger.error(dataset.show(10))
    dataset = dataset.filter(dataset.gender == 'F').groupBy('state', 'arrival_month').count()
    dataset = dataset.toDF('f_state', 'f_arrival_month', 'f_count')
    logger.error(dataset.show(10))
    return dataset

def main():
  
  logger = logging.getLogger(__name__)

  spark = SparkSession\
    .builder\
    .appName("sparkify_etl")\
    .getOrCreate()\

  spark.sparkContext.setLogLevel("ERROR")

  file_finder = FileFinder(CORE_PATH + '/immigration-data/', '*.sas7bdat')

  immigration_data_set = map(
    lambda file: generate_immigration_rdd(spark, file), file_finder.return_file_names()
  )

  immigration_data_set = list(map(return_rdd_column_subset, immigration_data_set))
  immigration_data = unionAll(immigration_data_set) 

  age_aggregate = immigration_data.groupBy('state', 'arrival_month').avg('age')
  sex_aggregate = immigration_data.groupBy('state', 'arrival_month').count()
  female_aggregate = create_female_distribution(logger, immigration_data)
  sex_distribution = create_sex_distribution_frame(logger, sex_aggregate, female_aggregate)

  # logger.error(example_sex.show(10))
  # logger.error(example_all.show(10))
  # logger.error(example_female.show(10))


  



if __name__ == '__main__':
  main()